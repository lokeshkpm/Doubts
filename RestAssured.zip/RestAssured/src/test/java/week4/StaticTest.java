package week4;

public class StaticTest {
	
	
	public static void main(String[] args) {
		System.out.println("inside main method");
	}
	
	static {
		System.out.println("inside static block");
	}

}
