package week3.day2;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PutPatchDelete {

	@Test
	public void put() {
		RestAssured.baseURI = "https://dev125568.service-now.com/api/now/table/incident/2a82789697ca6110fa0378411153afc7";

		RestAssured.authentication = RestAssured.basic("admin", "jM@5Rfg3Ht$V");

		RequestSpecification inputRequest = RestAssured.given().contentType(ContentType.JSON)
				.body("{\r\n" + "    \"short_description\":\"This is a Updated Test\"\r\n" + "    \r\n" + "}");

		Response response = inputRequest.put();

		response.prettyPrint();
	}
	
	@Test
	public void patch() {
		RestAssured.baseURI = "https://dev125568.service-now.com/api/now/table/incident/2a82789697ca6110fa0378411153afc7";

		RestAssured.authentication = RestAssured.basic("admin", "jM@5Rfg3Ht$V");

		RequestSpecification inputRequest = RestAssured.given().contentType(ContentType.JSON)
				.body("{\r\n" + "    \"short_description\":\"This is a Patch Updated Test\"\r\n" + "    \r\n" + "}");

		Response response = inputRequest.patch();

		response.prettyPrint();
	}
	
	@Test
	public void delete() {
		RestAssured.baseURI = "https://dev125568.service-now.com/api/now/table/incident/2a82789697ca6110fa0378411153afc7";

		RestAssured.authentication = RestAssured.basic("admin", "jM@5Rfg3Ht$V");

		RequestSpecification inputRequest = RestAssured.given();
		Response response = inputRequest.delete();

		response.prettyPrint();
	}

}
