package week3.day2;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Logs {

	@Test
	public void logsTest() {
		RestAssured.baseURI = "https://dev125568.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "jM@5Rfg3Ht$V");

		RequestSpecification input = RestAssured.given().contentType(ContentType.JSON).log().all();
		Response response = input.post();
		response.then().log().all();

	}

}
