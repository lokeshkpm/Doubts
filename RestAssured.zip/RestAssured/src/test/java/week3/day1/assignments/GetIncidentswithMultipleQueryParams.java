package week3.day1.assignments;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetIncidentswithMultipleQueryParams {
	
	
	@Test
	public void getInci() {
		
//		Step 1 - Requirements
		
		
		
//		Step 2 - Endpoint with resources
		
		RestAssured.baseURI = "https://dev78818.service-now.com/api/now/table/incident";
		
//		Step 3- construct the request (params, auth, etc)
		RestAssured.authentication = RestAssured.basic("admin", "rbw+!aZGT5Q0");
		
		Map<String,String> queryMap = new HashMap<String,String>();
		queryMap.put("sysparm_fields", "sys_id,category");
		queryMap.put("category", "hardware");		
		
		RequestSpecification inputRequest = RestAssured.given()
													   .queryParams(queryMap);
		
//		Step 4 - send the request(http methods)
		Response response = inputRequest.get();
		
//		Step 5 - Validate the response
		response.prettyPrint();
	}

}
