package week3.day1;

import org.testng.annotations.Test;

public class SampleTest {
	
	
//	
//	- Requirements
//	- Endpoint with resources
//	- construct the request (params, auth, etc)
//	- send the request(http methods)
//	- Validate the response
	
	@Test
	public void testVer() {
		System.out.println("testing");
	}

}
